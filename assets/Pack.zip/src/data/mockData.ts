import { AmbulanceCategory, Hospital, FirstAidGuide, UserProfile } from '../types';

export const AMBULANCE_CATEGORIES: AmbulanceCategory[] = [
  {
    id: 'basic',
    nameEn: 'Basic Life Support (BLS)',
    nameBn: 'বেসিক লাইফ সাপোর্ট (সাধারণ)',
    descriptionEn: 'Oxygen cylinder, stretcher, paramedic crew for non-critical emergencies.',
    descriptionBn: 'অক্সিজেন সিলিন্ডার, স্ট্রেচার এবং প্রাথমিক স্বাস্থ্য সহায়তাকারী সংবলিত।',
    iconName: 'Ambulance',
    baseFare: 1500,
    perKm: 50,
    estTimeMin: 4,
    badgeEn: 'Most Popular',
    badgeBn: 'সবচেয়ে জনপ্রিয়',
    features: ['24/7 Oxygen Supply', 'Folding Stretcher', 'Basic First Aid Kit', 'Trained Driver & Attendant'],
  },
  {
    id: 'icu',
    nameEn: 'ICU Ventilator Ambulance',
    nameBn: 'আইসিইউ ভেন্টিলেটর অ্যাম্বুলেন্স',
    descriptionEn: 'Advanced cardiac monitor, ventilator, suction unit & critical doctor on board.',
    descriptionBn: 'কার্ডিয়াক মনিটর, ভেন্টিলেটর ও ক্রিটিক্যাল কেয়ার ডাক্তার সমৃদ্ধ।',
    iconName: 'Activity',
    baseFare: 4500,
    perKm: 120,
    estTimeMin: 5,
    badgeEn: 'Critical Care',
    badgeBn: 'জরুরি কেয়ার',
    features: ['Portable ICU Ventilator', 'ECG & Defibrillator', 'Emergency Doctor on Board', 'Infusion Pump & Suction'],
  },
  {
    id: 'ac',
    nameEn: 'AC Comfort Ambulance',
    nameBn: 'এসি অ্যাম্বুলেন্স',
    descriptionEn: 'Air-conditioned patient transport for inter-hospital transfers.',
    descriptionBn: 'আরামদায়ক শীতাতপ নিয়ন্ত্রিত রোগী পরিবহন।',
    iconName: 'Wind',
    baseFare: 2200,
    perKm: 65,
    estTimeMin: 6,
    badgeEn: 'Patient Comfort',
    badgeBn: 'আরামদায়ক',
    features: ['Climate Control AC', 'Smooth Suspension Stretcher', 'Accommodates 2 Relatives', 'Sterilized Environment'],
  },
  {
    id: 'freezer',
    nameEn: 'Freezer Van (Morgue Transport)',
    nameBn: 'ফ্রিজার ভ্যান (মৃতদেহ পরিবহন)',
    descriptionEn: 'Temperature-controlled (-10°C) preserved body transport across Bangladesh.',
    descriptionBn: '-১০ ডিগ্রি সেলসিয়াস তাপমাত্রা নিয়ন্ত্রিত কফিন পরিবহন।',
    iconName: 'ThermometerSnowflake',
    baseFare: 3500,
    perKm: 80,
    estTimeMin: 8,
    badgeEn: 'Inter-City',
    badgeBn: 'দূরপাল্লার জন্য',
    features: ['Deep-Freeze Refrigeration (-10°C)', 'Odorous Seal System', '24hr Power Backup', 'Long-Distance Transport'],
  },
  {
    id: 'air',
    nameEn: 'Air Ambulance (Helicopter)',
    nameBn: 'এয়ার অ্যাম্বুলেন্স (হেলিকপ্টার)',
    descriptionEn: 'Rapid emergency air transport for critical trauma patient transfer.',
    descriptionBn: 'জরুরি দূরপাল্লার এয়ারলিফ্ট ও দ্রুততম ট্রমা স্থানান্তর।',
    iconName: 'Plane',
    baseFare: 35000,
    perKm: 500,
    estTimeMin: 15,
    badgeEn: 'Rapid Airlift',
    badgeBn: 'এয়ারলিফ্ট',
    features: ['Aviation Medical Team', 'Helipad Coordination', 'Full Critical ICU Rig', 'Countrywide Coverage'],
  },
];

export const HOSPITALS_DATA: Hospital[] = [
  {
    id: 'h1',
    name: 'Square Hospital Dhaka',
    address: '18/F, West Panthapath, Bir Uttam Qazi Nuruzzaman Sarak, Dhaka',
    phone: '10616',
    emergencyPhone: '+880 1713-333333',
    specialties: ['ICU & CCU', 'Trauma Center', 'Cardiology', 'Stroke Care'],
    rating: 4.8,
    lat: 23.7531,
    lng: 90.3807,
    icuAvailable: 4,
    generalBeds: 28,
    distanceKm: 1.2,
  },
  {
    id: 'h2',
    name: 'Evercare Hospital Dhaka',
    address: 'Plot 81, Block E, Bashundhara R/A, Dhaka',
    phone: '10678',
    emergencyPhone: '+880 1711-555555',
    specialties: ['24/7 ER', 'Emergency Cardiac', 'Pediatric ICU', 'Neuro Emergency'],
    rating: 4.9,
    lat: 23.8103,
    lng: 90.4312,
    icuAvailable: 7,
    generalBeds: 42,
    distanceKm: 6.4,
  },
  {
    id: 'h3',
    name: 'United Hospital Gulshan',
    address: 'Plot 15, Road 71, Gulshan 2, Dhaka',
    phone: '10666',
    emergencyPhone: '+880 1914-001234',
    specialties: ['Burn Unit', 'Emergency Surgery', 'Neonatal ICU', 'Chest Emergency'],
    rating: 4.7,
    lat: 23.7981,
    lng: 90.4189,
    icuAvailable: 2,
    generalBeds: 19,
    distanceKm: 4.8,
  },
  {
    id: 'h4',
    name: 'Dhaka Medical College Hospital (DMCH)',
    address: 'Secretariat Road, Ramna, Dhaka',
    phone: '02-55165088',
    emergencyPhone: '+880 2-9669340',
    specialties: ['Government Tertiary Care', 'Burn & Plastic Institute', 'Mass Casualty'],
    rating: 4.5,
    lat: 23.7259,
    lng: 90.3976,
    icuAvailable: 1,
    generalBeds: 120,
    distanceKm: 3.1,
  },
  {
    id: 'h5',
    name: 'Labaid Specialized Hospital',
    address: 'House 06, Road 04, Dhanmondi, Dhaka',
    phone: '10606',
    emergencyPhone: '+880 1713-043198',
    specialties: ['Cardiac Care', 'Neurology', 'Kidney Emergency'],
    rating: 4.6,
    lat: 23.7425,
    lng: 90.3828,
    icuAvailable: 5,
    generalBeds: 35,
    distanceKm: 2.0,
  },
  {
    id: 'h6',
    name: 'BSMMU (PGB Hospital)',
    address: 'Shahbagh, Dhaka 1000',
    phone: '02-55165701',
    emergencyPhone: '+880 2-55165700',
    specialties: ['Super Speciality', 'Organ Transplant', 'Poisoning Unit'],
    rating: 4.6,
    lat: 23.7385,
    lng: 90.3958,
    icuAvailable: 3,
    generalBeds: 60,
    distanceKm: 2.5,
  }
];

export const FIRST_AID_GUIDES: FirstAidGuide[] = [
  {
    id: 'fa1',
    category: 'cardiac',
    titleEn: 'CPR (Cardiopulmonary Resuscitation)',
    titleBn: 'সিপিআর (হৃদরোগ ও শ্বাস বন্ধ হলে)',
    shortSummaryEn: 'How to save someone whose heart has stopped or who is unbreathing.',
    shortSummaryBn: 'যার হৃদস্পন্দন বা শ্বাসপ্রশ্বাস বন্ধ হয়ে গেছে তার জীবন বাঁচানোর উপায়।',
    urgentNoticeEn: 'CALL 999 OR BOOK ICU AMBULANCE IMMEDIATELY BEFORE STARTING CPR!',
    urgentNoticeBn: 'সিপিআর শুরুর আগে অবিলম্বে ৯৯৯ নম্বরে কল করুন বা আইসিইউ অ্যাম্বুলেন্স বুক করুন!',
    stepsEn: [
      'Check if the victim is conscious by tapping their shoulder firmly and asking loudly: "Are you okay?"',
      'Place victim on their back on a firm, flat surface.',
      'Place heel of one hand in center of chest, place other hand on top and interlock fingers.',
      'Push hard and fast at a rate of 100-120 compressions per minute (to the beat of "Stayin Alive"). Compress chest at least 2 inches deep.',
      'Allow full chest recoil after each push.',
      'Continue chest compressions until ambulance paramedic arrives or an AED is ready.'
    ],
    stepsBn: [
      'রোগীর কাঁধে আলতো করে থাপ্পড় দিন এবং জোরে জিজ্ঞেস করুন: "আপনি কি ঠিক আছেন?"',
      'রোগীকে সমতল ও শক্ত জায়গায় পিঠ ভর দিয়ে শুইয়ে দিন।',
      'বুকের ঠিক মাঝখানে এক হাতের তালুর গোড়ালি রাখুন, অন্য হাত দিয়ে আঙুলগুলো লক করুন।',
      'প্রতি মিনিটে ১০০-১২০ বার গতিতে শক্তভাবে চাপ দিন (কমপক্ষে ২ ইঞ্চি গভীরে)।',
      'প্রতিবার চাপের পর বুক স্বাভাবিক জায়গায় ফিরতে দিন।',
      'অ্যাম্বুলেন্স না আসা পর্যন্ত সিপিআর চালিয়ে যান।'
    ],
    icon: 'HeartPulse'
  },
  {
    id: 'fa2',
    category: 'choking',
    titleEn: 'Choking Response (Heimlich Maneuver)',
    titleBn: 'গলায় কিছু আটকে দম বন্ধ হওয়া (হাইমলিক পদ্ধতি)',
    shortSummaryEn: 'Emergency steps when an adult or child is choking and cannot speak or breathe.',
    shortSummaryBn: 'কেউ কথা বলতে না পারলে বা দম আটকে থাকলে করণীয়।',
    urgentNoticeEn: 'If victim turns blue or loses consciousness, lower them to the floor and begin CPR!',
    urgentNoticeBn: 'রোগী জ্ঞান হারালে সঙ্গে সঙ্গে মাটিতে শুইয়ে সিপিআর শুরু করুন!',
    stepsEn: [
      'Stand behind the choking person and wrap your arms around their waist.',
      'Make a fist with one hand and place the thumb side against their abdomen, just above the navel.',
      'Grasp your fist with your other hand and give quick, upward abdominal thrusts.',
      'Repeat thrusts until the object is expelled or the person collapses.',
      'For babies under 1 year: Give 5 back blows between shoulder blades followed by 5 chest thrusts.'
    ],
    stepsBn: [
      'আক্রান্ত ব্যক্তির পেছনে গিয়ে দুই হাত দিয়ে তার কোমর জড়িয়ে ধরুন।',
      'এক হাত মুঠো করে নাভির ঠিক ওপরে পেট লক্ষ্য করে বুড়ো আঙুল ভেতরের দিকে বসান।',
      'অন্য হাত দিয়ে মুষ্টি শক্ত করে ধরে সজোরে ভেতরের দিকে ও উপরের দিকে ধাক্কা দিন।',
      'বস্তুটি বের না হওয়া পর্যন্ত এই ধাক্কা পুনরাবৃত্তি করুন।',
      '১ বছরের কম শিশুদের ক্ষেত্রে: দুই কাঁধের মাঝে ৫ বার চাপড় ও বুকে ৫ বার চাপ দিন।'
    ],
    icon: 'Wind'
  },
  {
    id: 'fa3',
    category: 'bleeding',
    titleEn: 'Severe Bleeding Control',
    titleBn: 'প্রচুর রক্তপাত নিয়ন্ত্রণ',
    shortSummaryEn: 'Stopping heavy arterial or traumatic wound bleeding using direct pressure.',
    shortSummaryBn: 'মারাত্মক জখম বা ক্ষত থেকে অতিরিক্ত রক্তক্ষরণ বন্ধের কৌশল।',
    urgentNoticeEn: 'Do NOT remove embedded objects. Apply pressure AROUND the object!',
    urgentNoticeBn: 'শরীরে কোনো বস্তু ঢুকে থাকলে তা টেনে বের করবেন না, চারপাশে চাপ দিন!',
    stepsEn: [
      'Apply direct, continuous pressure on the wound using a clean cloth or sterile gauze.',
      'Keep firm pressure for at least 10 minutes without lifting the cloth to check.',
      'Elevate the bleeding limb above heart level if no bone fracture is suspected.',
      'If blood soaks through, place another cloth ON TOP of the first. Do not remove original cloth.',
      'Secure bandage firmly and keep patient warm until ambulance arrives.'
    ],
    stepsBn: [
      'পরিষ্কার কাপড় বা গজ দিয়ে ক্ষতস্থানে সরাসরি শক্ত করে চাপ দিয়ে ধরে রাখুন।',
      'কমপক্ষে ১০ মিনিট না তুলে অবিরাম চাপ দিয়ে রাখুন।',
      'হাত বা পা কেটে গেলে বুক থেকে উঁচুতে তুলে রাখুন।',
      'কাপড় রক্তে ভিজে গেলে আগেরটি না সরিয়ে তার ওপর আরও কাপড় যোগ করুন।',
      'রোগীকে শান্ত ও গরম রাখুন এবং অ্যাম্বুলেন্সের জন্য অপেক্ষা করুন।'
    ],
    icon: 'ShieldAlert'
  },
  {
    id: 'fa4',
    category: 'stroke',
    titleEn: 'Recognizing Stroke (F.A.S.T)',
    titleBn: 'স্ট্রোকের লক্ষণ চেনার উপায় (F.A.S.T)',
    shortSummaryEn: 'Time is brain tissue! Spot stroke symptoms early to save lives.',
    shortSummaryBn: 'সময়ই মস্তিষ্ক! দ্রুত স্ট্রোক শনাক্তকরণ এবং জরুরি পদক্ষেপ।',
    urgentNoticeEn: 'Brain cells die rapidly during stroke. Reach hospital within 3 golden hours!',
    urgentNoticeBn: 'স্ট্রোকের গোল্ডেন আওয়ারের (৩ ঘণ্টা) মধ্যে আইসিইউ সমৃদ্ধ হাসপাতালে পৌঁছানো জরুরি!',
    stepsEn: [
      'F - FACE: Ask the person to smile. Does one side of the face droop?',
      'A - ARMS: Ask the person to raise both arms. Does one arm drift downward?',
      'S - SPEECH: Ask the person to repeat a simple sentence. Is speech slurred or strange?',
      'T - TIME: If you see any of these signs, call Ambulife ICU Ambulance immediately!'
    ],
    stepsBn: [
      'F - মুখ (Face): রোগীকে হাসতে বলুন। মুখের একপাশ বেঁকে যাচ্ছে কি?',
      'A - হাত (Arms): দুটি হাত ওপরে তুলতে বলুন। এক হাত কি নিচে নেমে যাচ্ছে?',
      'S - কথা (Speech): সহজ কথা বলতে বলুন। কথা কি জড়িয়ে যাচ্ছে?',
      'T - সময় (Time): এই লক্ষণগুলো দেখা মাত্র অবিলম্বে অ্যাম্বুলেন্স ডাকুন!'
    ],
    icon: 'Brain'
  }
];

export const INITIAL_USER_PROFILE: UserProfile = {
  name: 'Farhan Ahmed',
  phone: '+880 1712-345678',
  bloodGroup: 'O+ Positive',
  medicalConditions: ['Hypertension', 'Penicillin Allergy'],
  savedAddresses: [
    { label: 'Home (Residence)', address: 'Flat 4A, House 12, Road 27, Dhanmondi, Dhaka', lat: 23.7508, lng: 90.3751 },
    { label: 'Office (Workplace)', address: 'Level 8, Tower B, Bashundhara City, Panthapath, Dhaka', lat: 23.7512, lng: 90.3905 }
  ],
  emergencyContacts: [
    { name: 'Dr. Shahriar Ahmed (Brother)', relation: 'Sibling', phone: '+880 1819-998877' },
    { name: 'Nusrat Jahan (Wife)', relation: 'Spouse', phone: '+880 1911-223344' }
  ]
};
