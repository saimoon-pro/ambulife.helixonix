import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  PhoneCall, 
  MapPin, 
  CheckCircle2, 
  BedDouble, 
  Activity, 
  Star, 
  Zap,
  Navigation
} from 'lucide-react';
import { Hospital, Language } from '../types';
import { HOSPITALS_DATA } from '../data/mockData';

interface HospitalDirectoryProps {
  lang: Language;
  onSelectHospitalForBooking: (hospitalName: string) => void;
}

export const HospitalDirectory: React.FC<HospitalDirectoryProps> = ({
  lang,
  onSelectHospitalForBooking,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSpecialty, setFilterSpecialty] = useState<string>('all');

  const filteredHospitals = HOSPITALS_DATA.filter((h) => {
    const query = searchQuery.toLowerCase();
    const matchesQuery =
      h.name.toLowerCase().includes(query) ||
      h.address.toLowerCase().includes(query) ||
      h.specialties.some((s) => s.toLowerCase().includes(query));

    const matchesSpecialty =
      filterSpecialty === 'all' ||
      (filterSpecialty === 'icu' && h.icuAvailable > 0) ||
      h.specialties.some((s) => s.toLowerCase().includes(filterSpecialty));

    return matchesQuery && matchesSpecialty;
  });

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      
      {/* Header Banner */}
      <div className="bg-[#003366] text-white rounded-3xl p-6 sm:p-8 shadow-xl mb-8 border border-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-white/10 text-amber-400 border border-white/20 px-3 py-1 rounded-full text-xs font-extrabold uppercase mb-2">
            <Building2 className="w-4 h-4" />
            {lang === 'en' ? 'Verified Hospital Emergency Network' : 'যাচাইকৃত হাসপাতাল ও আইসিইউ নেটওয়ার্ক'}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {lang === 'en' ? 'Find Nearby Hospitals & ICU Availability' : 'নিকটস্থ হাসপাতাল ও আইসিইউ শয্যা তথ্য'}
          </h1>
          <p className="text-slate-200 text-xs sm:text-sm mt-1">
            {lang === 'en'
              ? 'Real-time emergency bed status, direct ER hotline numbers, and one-tap destination routing.'
              : 'জরুরি রুম, আইসিইউ শয্যা এবং সরাসরি হাসপাতাল হটলাইনের তালিকা।'}
          </p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-sm mb-8 flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-96">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'en' ? 'Search hospital name, address, or specialty...' : 'হাসপাতাল বা স্পেশালিটি খুঁজুন...'}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border-2 border-slate-100 rounded-2xl text-sm font-semibold text-slate-900 focus:border-[#003366] outline-hidden transition-all"
          />
          <Search className="w-5 h-5 text-slate-400 absolute left-3 top-3" />
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          {[
            { id: 'all', label: lang === 'en' ? 'All Hospitals' : 'সব হাসপাতাল' },
            { id: 'icu', label: lang === 'en' ? 'ICU Available' : 'আইসিইউ খালি' },
            { id: 'cardiac', label: lang === 'en' ? 'Cardiac Emergency' : 'হার্ট কেয়ার' },
            { id: 'trauma', label: lang === 'en' ? 'Trauma & ER' : 'ট্রমা সেন্টারা' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterSpecialty(tab.id)}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                filterSpecialty === tab.id
                  ? 'bg-[#003366] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Hospitals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredHospitals.map((h) => (
          <div
            key={h.id}
            className="bg-white rounded-3xl border border-white shadow-xl shadow-slate-200/50 hover:shadow-2xl transition-all p-6 flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-black text-slate-900 leading-snug">{h.name}</h3>
                  <p className="text-xs text-slate-500 font-semibold flex items-center gap-1 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    <span className="line-clamp-1">{h.address}</span>
                  </p>
                </div>

                <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full shrink-0">
                  <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  <span className="text-xs font-black text-slate-900">{h.rating}</span>
                </div>
              </div>

              {/* ICU & Bed Availability Badges */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-3 text-emerald-950">
                  <p className="text-[10px] font-extrabold uppercase text-emerald-800 flex items-center gap-1">
                    <Activity className="w-3 h-3 text-emerald-600" /> ICU Beds
                  </p>
                  <p className="text-base font-black text-emerald-900 mt-0.5">
                    {h.icuAvailable} <span className="text-xs font-semibold">Beds Free</span>
                  </p>
                </div>

                <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-3 text-blue-950">
                  <p className="text-[10px] font-extrabold uppercase text-blue-800 flex items-center gap-1">
                    <BedDouble className="w-3 h-3 text-blue-600" /> General ER
                  </p>
                  <p className="text-base font-black text-blue-900 mt-0.5">
                    {h.generalBeds} <span className="text-xs font-semibold">Beds Free</span>
                  </p>
                </div>
              </div>

              {/* Specialties Chips */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {h.specialties.map((spec, idx) => (
                  <span key={idx} className="bg-slate-100 text-slate-700 text-[11px] font-bold px-2.5 py-1 rounded-full border border-slate-200">
                    {spec}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions: Direct Call & Set Destination */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-2 gap-2">
              <a
                href={`tel:${h.emergencyPhone}`}
                className="bg-[#003366] hover:bg-blue-900 text-amber-400 font-extrabold py-3 px-3 rounded-2xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                <span>Call ER Hotline</span>
              </a>

              <button
                onClick={() => onSelectHospitalForBooking(h.name)}
                className="bg-[#FFCC00] hover:bg-amber-400 text-slate-950 font-black py-3 px-3 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer uppercase tracking-wider"
              >
                <Zap className="w-3.5 h-3.5 fill-slate-950" />
                <span>Set Destination</span>
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
