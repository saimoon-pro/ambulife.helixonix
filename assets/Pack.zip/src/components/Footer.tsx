import React from 'react';
import { Ambulance, PhoneCall, ShieldCheck, Heart, Sparkles, MapPin } from 'lucide-react';
import { Language } from '../types';
import { Logo } from './Logo';

interface FooterProps {
  lang: Language;
  onNavigateTab: (tab: string) => void;
  onOpenSosModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onNavigateTab,
  onOpenSosModal,
}) => {
  return (
    <footer className="bg-[#003366] text-white border-t border-blue-900 pt-12 pb-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-blue-900/60">
        
        {/* Brand Column */}
        <div className="md:col-span-5 space-y-4">
          <Logo size="lg" variant="dark" />

          <p className="text-slate-200 text-xs sm:text-sm max-w-sm leading-relaxed">
            {lang === 'en'
              ? 'Your safety is our first priority. Ambulife delivers one-tap emergency ambulance dispatch, live GPS vehicle tracking, and 24/7 AI-guided triage across Bangladesh.'
              : 'আপনার সুরক্ষাই আমাদের প্রথম অগ্রাধিকার। এক চাপে দ্রুততম জরুরি অ্যাম্বুলেন্স সেবা ও জিপিএস ট্র্যাকিং নেটওয়ার্ক।'}
          </p>

          <div className="flex items-center gap-3 pt-2 text-xs font-bold text-amber-400">
            <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-emerald-400" /> ISO Certified</span>
            <span>•</span>
            <span className="flex items-center gap-1"><Heart className="w-4 h-4 text-red-500" /> 24/7 Paramedics</span>
          </div>
        </div>

        {/* Quick Links Column */}
        <div className="md:col-span-3 space-y-3">
          <h4 className="text-xs font-black uppercase text-amber-400 tracking-wider">
            {lang === 'en' ? 'Emergency Navigation' : 'জরুরি মেনু'}
          </h4>
          <ul className="space-y-2 text-xs font-semibold text-slate-200">
            <li>
              <button onClick={() => onNavigateTab('book')} className="hover:text-amber-400 transition-colors cursor-pointer">
                {lang === 'en' ? 'Book Ambulance' : 'অ্যাম্বুলেন্স বুক করুন'}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateTab('track')} className="hover:text-amber-400 transition-colors cursor-pointer">
                {lang === 'en' ? 'Live GPS Dispatch Tracker' : 'লাইভ জিপিএস ট্র্যাকিং'}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateTab('chat')} className="hover:text-amber-400 transition-colors cursor-pointer">
                {lang === 'en' ? 'AI Emergency Chatbot' : 'এআই চ্যাট অ্যাসিস্ট্যান্ট'}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateTab('firstaid')} className="hover:text-amber-400 transition-colors cursor-pointer">
                {lang === 'en' ? 'First-Aid CPR Guides' : 'ফার্স্ট-এইড গাইড'}
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateTab('hospitals')} className="hover:text-amber-400 transition-colors cursor-pointer">
                {lang === 'en' ? 'Nearby Hospital Bed Finder' : 'হাসপাতাল ও আইসিইউ শয্যা'}
              </button>
            </li>
          </ul>
        </div>

        {/* Hotlines Column */}
        <div className="md:col-span-4 space-y-3 bg-white/10 p-5 rounded-3xl border border-white/20">
          <h4 className="text-xs font-black uppercase text-amber-400 tracking-wider">
            {lang === 'en' ? 'Instant Emergency Dispatch' : 'জরুরি কল সেবাসমূহ'}
          </h4>

          <div className="space-y-2 text-xs font-bold">
            <a href="tel:10616" className="flex items-center justify-between bg-white/10 hover:bg-white/20 p-2.5 rounded-2xl text-white transition-colors">
              <span>Ambulife Dispatch Center</span>
              <span className="text-amber-400 font-extrabold text-sm">10616</span>
            </a>

            <a href="tel:999" className="flex items-center justify-between bg-white/10 hover:bg-white/20 p-2.5 rounded-2xl text-white transition-colors">
              <span>National Emergency Police & ER</span>
              <span className="text-red-400 font-extrabold text-sm">999</span>
            </a>
          </div>

          <button
            onClick={onOpenSosModal}
            className="w-full bg-[#FFCC00] hover:bg-amber-400 text-slate-950 font-black py-3 rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer uppercase tracking-wider"
          >
            <PhoneCall className="w-4 h-4 fill-slate-950" />
            <span>{lang === 'en' ? 'OPEN SOS HELPLINE MODAL' : 'জরুরি হেল্পলাইন ডায়ালগ'}</span>
          </button>
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row justify-between items-center text-slate-300 text-xs font-medium gap-2">
        <p>© 2026 Ambulife Bangladesh Inc. All Rights Reserved. Clean Minimalist UI.</p>
        <p>Built for rapid response & life safety.</p>
      </div>
    </footer>
  );
};
