import React from 'react';
import { PhoneCall, ShieldAlert, X, Zap, HeartPulse, Building2 } from 'lucide-react';
import { Language } from '../types';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const SosModal: React.FC<SosModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 text-slate-900 shadow-2xl border border-slate-200 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center space-y-3 mb-6">
          <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto animate-bounce">
            <PhoneCall className="w-8 h-8 fill-red-600" />
          </div>
          <h2 className="text-2xl font-black text-slate-900">
            {lang === 'en' ? 'Direct Emergency SOS Lines' : 'জরুরি হেল্পলাইন নম্বরসমূহ'}
          </h2>
          <p className="text-xs text-slate-500 font-medium max-w-xs mx-auto">
            {lang === 'en'
              ? 'Tap any number below to dial immediately for emergency ambulance dispatch or police help.'
              : 'জরুরি অ্যাম্বুলেন্স বা পুলিশ সহায়তার জন্য যেকোনো নম্বরে চাপ দিন।'}
          </p>
        </div>

        <div className="space-y-3">
          <a
            href="tel:10616"
            className="flex items-center justify-between bg-[#FFCC00] hover:bg-amber-400 text-slate-950 font-black p-4 rounded-2xl shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <Zap className="w-6 h-6 fill-slate-950 group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-sm uppercase font-extrabold">Ambulife Hotline</p>
                <p className="text-[11px] font-semibold text-slate-900">24/7 Ambulance Dispatch</p>
              </div>
            </div>
            <span className="text-xl font-black">10616</span>
          </a>

          <a
            href="tel:999"
            className="flex items-center justify-between bg-red-600 hover:bg-red-500 text-white font-black p-4 rounded-2xl shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-6 h-6 fill-white group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-sm uppercase font-extrabold">National Emergency</p>
                <p className="text-[11px] font-semibold text-red-100">Police, Fire & Medical</p>
              </div>
            </div>
            <span className="text-xl font-black">999</span>
          </a>

          <a
            href="tel:16263"
            className="flex items-center justify-between bg-[#003366] hover:bg-blue-900 text-white font-black p-4 rounded-2xl shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <HeartPulse className="w-6 h-6 text-amber-400 group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-sm uppercase font-extrabold">Health Service Call</p>
                <p className="text-[11px] font-semibold text-blue-200">Govt Health Line</p>
              </div>
            </div>
            <span className="text-xl font-black">16263</span>
          </a>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 text-center">
          <button
            onClick={onClose}
            className="text-xs font-extrabold text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            {lang === 'en' ? 'Close SOS Modal' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
