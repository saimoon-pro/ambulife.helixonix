import React, { useEffect, useRef, useState } from 'react';
import { 
  Phone, 
  MapPin, 
  Navigation, 
  Clock, 
  ShieldCheck, 
  Share2, 
  XCircle, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw,
  Copy,
  ExternalLink
} from 'lucide-react';
import { Booking, Language } from '../types';
import L from 'leaflet';

interface LiveTrackerMapProps {
  booking: Booking | null;
  lang: Language;
  onCancelBooking: (bookingId: string) => void;
  onNewBooking: () => void;
}

export const LiveTrackerMap: React.FC<LiveTrackerMapProps> = ({
  booking,
  lang,
  onCancelBooking,
  onNewBooking,
}) => {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const leafletMapInstance = useRef<L.Map | null>(null);
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);

  const [copiedLink, setCopiedLink] = useState(false);
  const [liveBooking, setLiveBooking] = useState<Booking | null>(booking);
  const [showCancelModal, setShowCancelModal] = useState(false);

  // Sync prop changes to local state
  useEffect(() => {
    setLiveBooking(booking);
  }, [booking]);

  // Poll server every 3 seconds for live GPS updates & driver location
  useEffect(() => {
    if (!liveBooking || liveBooking.status === 'cancelled' || liveBooking.status === 'completed') return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/bookings/${liveBooking.id}`);
        if (res.ok) {
          const updated: Booking = await res.json();
          setLiveBooking(updated);

          // Update marker position on map dynamically
          if (driverMarkerRef.current && updated.driver) {
            driverMarkerRef.current.setLatLng([updated.driver.latitude, updated.driver.longitude]);
          }
        }
      } catch (err) {
        console.warn('Polling status error', err);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [liveBooking?.id, liveBooking?.status]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapRef.current || !liveBooking) return;

    // Clean up previous map if exists
    if (leafletMapInstance.current) {
      leafletMapInstance.current.remove();
      leafletMapInstance.current = null;
    }

    const { pickupCoords, hospitalCoords, driver } = liveBooking;

    // Create Map instance
    const map = L.map(mapRef.current, {
      center: [pickupCoords.lat, pickupCoords.lng],
      zoom: 14,
      zoomControl: true,
    });

    leafletMapInstance.current = map;

    // OpenStreetMap Tile Layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    // Custom Icon Helpers
    const ambulanceHtmlIcon = L.divIcon({
      className: 'custom-ambulance-marker',
      html: `
        <div style="background-color: #eab308; border: 3px solid #0f172a; padding: 6px; border-radius: 9999px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; width: 42px; height: 42px;">
          <span style="font-size: 20px;">🚑</span>
        </div>
      `,
      iconSize: [42, 42],
      iconAnchor: [21, 21],
    });

    const pickupHtmlIcon = L.divIcon({
      className: 'custom-pickup-marker',
      html: `
        <div style="background-color: #ef4444; color: white; padding: 6px; border-radius: 9999px; border: 3px solid white; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; width: 36px; height: 36px;">
          <span style="font-size: 16px;">📍</span>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });

    const hospitalHtmlIcon = L.divIcon({
      className: 'custom-hospital-marker',
      html: `
        <div style="background-color: #1e40af; color: white; padding: 6px; border-radius: 9999px; border: 3px solid white; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; width: 36px; height: 36px;">
          <span style="font-size: 16px;">🏥</span>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });

    // Add Driver Marker
    const driverMarker = L.marker([driver.latitude, driver.longitude], { icon: ambulanceHtmlIcon })
      .addTo(map)
      .bindPopup(`<b>Ambulance En-Route</b><br>${driver.name} (${driver.vehicleNo})`);
    driverMarkerRef.current = driverMarker;

    // Add Pickup Marker
    const pickupMarker = L.marker([pickupCoords.lat, pickupCoords.lng], { icon: pickupHtmlIcon })
      .addTo(map)
      .bindPopup(`<b>Patient Pickup Spot</b><br>${liveBooking.pickupLocation}`);
    pickupMarkerRef.current = pickupMarker;

    // Add Hospital Marker
    L.marker([hospitalCoords.lat, hospitalCoords.lng], { icon: hospitalHtmlIcon })
      .addTo(map)
      .bindPopup(`<b>Destination Hospital</b><br>${liveBooking.destinationHospital}`);

    // Draw route Polyline
    const polylinePoints: [number, number][] = [
      [driver.latitude, driver.longitude],
      [pickupCoords.lat, pickupCoords.lng],
      [hospitalCoords.lat, hospitalCoords.lng],
    ];
    L.polyline(polylinePoints, { color: '#2563eb', weight: 4, dashArray: '8, 8' }).addTo(map);

    // Fit bounds to show all markers
    const group = L.featureGroup([driverMarker, pickupMarker]);
    map.fitBounds(group.getBounds().pad(0.3));

    return () => {
      if (leafletMapInstance.current) {
        leafletMapInstance.current.remove();
        leafletMapInstance.current = null;
      }
    };
  }, [liveBooking?.id]);

  const handleShareLocation = () => {
    if (!liveBooking) return;
    const url = `${window.location.origin}?track=${liveBooking.id}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  if (!liveBooking) {
    return (
      <div className="max-w-4xl mx-auto my-12 px-4 text-center py-16 bg-white rounded-3xl border border-slate-200 shadow-xs">
        <div className="w-16 h-16 bg-blue-100 text-blue-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Navigation className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900">
          {lang === 'en' ? 'No Active Emergency Booking' : 'কোনো সক্রিয় অ্যাম্বুলেন্স ট্র্যাকিং নেই'}
        </h2>
        <p className="text-sm text-slate-600 max-w-md mx-auto mt-2">
          {lang === 'en'
            ? 'You currently have no dispatched ambulance. Book an ambulance in seconds to enable live GPS tracking.'
            : 'আপনার বর্তমানে কোনো সক্রিয় বুকিং নেই। জিপিএস ট্র্যাকিংয়ের জন্য এক চাপে বুকিং করুন।'}
        </p>
        <button
          onClick={onNewBooking}
          className="mt-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-6 py-3 rounded-xl shadow-md transition-all cursor-pointer uppercase tracking-wider"
        >
          {lang === 'en' ? 'Book Ambulance Now' : 'এখনই বুক করুন'}
        </button>
      </div>
    );
  }

  const isCancelled = liveBooking.status === 'cancelled';

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      
      {/* Header Banner */}
      <div className="bg-[#003366] text-white rounded-3xl p-6 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-500 text-slate-950 rounded-2xl flex items-center justify-center text-2xl font-bold shadow-md">
            🚑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-white uppercase tracking-tight">
                {lang === 'en' ? 'Emergency Dispatch Tracker' : 'জরুরি জিপিএস ট্র্যাকিং'}
              </h1>
              <span className="bg-white/10 text-amber-300 text-xs font-mono font-bold px-3 py-0.5 rounded-full border border-white/20">
                #{liveBooking.id}
              </span>
            </div>
            <p className="text-xs text-slate-200 font-medium mt-0.5">
              {liveBooking.pickupLocation} ➔ {liveBooking.destinationHospital}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <button
            onClick={handleShareLocation}
            className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-4 py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer"
          >
            {copiedLink ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-amber-400" />}
            <span>{copiedLink ? (lang === 'en' ? 'Link Copied!' : 'লিংক কপি হয়েছে!') : (lang === 'en' ? 'Share Live GPS' : 'শেয়ার করুন')}</span>
          </button>

          {!isCancelled && (
            <button
              onClick={() => setShowCancelModal(true)}
              className="flex items-center gap-1.5 bg-red-600/80 hover:bg-red-600 text-white px-4 py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer"
            >
              <XCircle className="w-4 h-4 text-white" />
              <span>{lang === 'en' ? 'Cancel Ride' : 'ক্যানসেল রাইড'}</span>
            </button>
          )}
        </div>
      </div>

      {isCancelled ? (
        <div className="bg-red-50 border border-red-200 rounded-3xl p-8 text-center max-w-xl mx-auto my-8">
          <AlertTriangle className="w-12 h-12 text-red-600 mx-auto mb-3" />
          <h3 className="text-xl font-bold text-red-900">
            {lang === 'en' ? 'Ride Request Cancelled' : 'রাইড টি বাতিল করা হয়েছে'}
          </h3>
          <p className="text-sm text-red-700 mt-2">
            {lang === 'en'
              ? 'This ambulance dispatch was cancelled. If you still need help, please request a new ambulance immediately.'
              : 'এই বুকিংটি বাতিল করা হয়েছে। জরুরি সহায়তার জন্য নতুন বুকিং করুন।'}
          </p>
          <button
            onClick={onNewBooking}
            className="mt-6 bg-[#003366] text-white font-bold px-6 py-3 rounded-2xl hover:bg-blue-900 transition-colors"
          >
            {lang === 'en' ? 'Create New Booking' : 'নতুন বুকিং করুন'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Interactive Leaflet Map */}
          <div className="lg:col-span-8 bg-white rounded-[32px] border-4 border-white shadow-xl shadow-slate-200/50 overflow-hidden relative">
            <div className="h-[450px] sm:h-[500px] w-full" ref={mapRef}></div>

            {/* Floating Live Status Overlay */}
            <div className="absolute top-4 left-4 right-4 sm:right-auto bg-[#003366]/95 text-white backdrop-blur-md p-5 rounded-2xl shadow-xl border border-white/10 z-10 flex items-center justify-between gap-6">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-amber-400 font-bold block">
                  {lang === 'en' ? 'Estimated Arrival Time' : 'আনুমানিক পৌঁছানোর সময়'}
                </span>
                <p className="text-2xl font-black text-white flex items-center gap-2">
                  <Clock className="w-6 h-6 text-amber-400 animate-pulse" />
                  <span>{liveBooking.etaMinutes} {lang === 'en' ? 'Minutes' : 'মিনিট'}</span>
                </p>
              </div>

              <div className="text-right border-l border-white/20 pl-5">
                <span className="inline-block h-2.5 w-2.5 rounded-full bg-emerald-500 animate-ping mr-1.5"></span>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                  {liveBooking.status === 'dispatched' && (lang === 'en' ? 'Dispatched' : 'কনফার্ম হয়েছে')}
                  {liveBooking.status === 'en_route' && (lang === 'en' ? 'En-Route (On Way)' : 'পিকআপের দিকে রওনা')}
                  {liveBooking.status === 'arrived' && (lang === 'en' ? 'Arrived at Pickup' : 'পিকআপ স্পটে পৌঁছেছে')}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Driver & Ambulance Details Card */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Driver Profile */}
            <div className="bg-white rounded-3xl border border-white shadow-xl shadow-slate-200/50 p-6">
              <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                <img
                  src={liveBooking.driver.avatar}
                  alt={liveBooking.driver.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-xs"
                />
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900">{liveBooking.driver.name}</h3>
                  <p className="text-xs font-bold text-amber-600 flex items-center gap-1">
                    ★ {liveBooking.driver.rating} Rating • <span className="text-slate-600 font-normal">Verified Senior Medic</span>
                  </p>
                  <p className="text-xs font-mono font-extrabold bg-slate-100 text-slate-800 px-2.5 py-0.5 rounded-full mt-1 inline-block">
                    {liveBooking.driver.vehicleNo}
                  </p>
                </div>
              </div>

              {/* Action: Direct Call Button */}
              <div className="pt-4">
                <a
                  href={`tel:${liveBooking.driver.phone}`}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-4 rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer text-sm uppercase tracking-wide"
                >
                  <Phone className="w-5 h-5 fill-white" />
                  <span>{lang === 'en' ? 'Call Driver Now' : 'ড্রাইভারকে কল করুন'}</span>
                </a>
              </div>

              {/* Equipment Installed */}
              <div className="mt-5 pt-4 border-t border-slate-100 space-y-2">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {lang === 'en' ? 'Vehicle Equipment Loaded' : 'গাড়ির জরুরি মেডিকেল সরঞ্জাম'}
                </p>
                <div className="flex flex-wrap gap-1.5 text-xs font-semibold text-slate-700">
                  <span className="bg-blue-50 text-blue-900 px-2.5 py-1 rounded-xl border border-blue-200">🫁 Medical Oxygen 24/7</span>
                  <span className="bg-blue-50 text-blue-900 px-2.5 py-1 rounded-xl border border-blue-200">💓 Automated Defibrillator</span>
                  <span className="bg-blue-50 text-blue-900 px-2.5 py-1 rounded-xl border border-blue-200">🩺 Paramedic Kit</span>
                </div>
              </div>
            </div>

            {/* Ride Details Summary */}
            <div className="bg-[#003366] text-white rounded-3xl p-6 shadow-md space-y-3 text-sm">
              <h4 className="font-extrabold text-amber-400 uppercase tracking-wider text-xs">
                {lang === 'en' ? 'Dispatch Summary' : 'বুকিং বিবরণী'}
              </h4>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-300">Category:</span>
                  <span className="font-bold uppercase text-white">{liveBooking.ambulanceType} Ambulance</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Condition:</span>
                  <span className="font-bold text-amber-300">{liveBooking.patientCondition}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Contact:</span>
                  <span className="font-mono text-white">{liveBooking.contactNumber}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-white/10 text-sm font-black">
                  <span className="text-slate-200">Estimated Fare:</span>
                  <span className="text-amber-400">৳{liveBooking.fareEstimate}</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 text-slate-900 shadow-2xl border border-slate-200">
            <h3 className="text-xl font-black text-red-900 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-red-600" />
              {lang === 'en' ? 'Cancel Ambulance Dispatch?' : 'অ্যাম্বুলেন্স বুকিং বাতিল করবেন?'}
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              {lang === 'en'
                ? 'An ambulance and medical crew have already been dispatched to your location. Are you sure you want to cancel?'
                : 'আপনার অবস্থানের দিকে মেডিকেল টিম রওনা হয়েছে। আপনি কি সত্যি এটি বাতিল করতে চান?'}
            </p>

            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={() => setShowCancelModal(false)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-4 rounded-xl cursor-pointer"
              >
                {lang === 'en' ? 'Keep Dispatch' : 'বাতিল করবেন না'}
              </button>
              <button
                onClick={() => {
                  onCancelBooking(liveBooking.id);
                  setShowCancelModal(false);
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-extrabold py-2.5 px-4 rounded-xl cursor-pointer"
              >
                {lang === 'en' ? 'Yes, Cancel' : 'হ্যাঁ, বাতিল করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
