import React, { useState } from 'react';
import { 
  Navigation, 
  MapPin, 
  Building2, 
  Phone, 
  Activity, 
  Clock, 
  ShieldCheck, 
  HeartPulse, 
  Sparkles,
  Zap,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { AmbulanceType, Language, Hospital } from '../types';
import { AMBULANCE_CATEGORIES, HOSPITALS_DATA } from '../data/mockData';

interface HeroBookingProps {
  lang: Language;
  onBook: (bookingData: {
    pickupLocation: string;
    destinationHospital: string;
    ambulanceType: AmbulanceType;
    patientCondition: string;
    contactNumber: string;
    userCoords?: { lat: number; lng: number };
  }) => void;
  onNavigateTab: (tab: string) => void;
}

export const HeroBooking: React.FC<HeroBookingProps> = ({
  lang,
  onBook,
  onNavigateTab,
}) => {
  const [pickupLocation, setPickupLocation] = useState('House 12, Road 27, Dhanmondi, Dhaka');
  const [destinationHospital, setDestinationHospital] = useState(HOSPITALS_DATA[0].name);
  const [selectedCategory, setSelectedCategory] = useState<AmbulanceType>('basic');
  const [patientCondition, setPatientCondition] = useState('Cardiac Chest Pain');
  const [contactNumber, setContactNumber] = useState('+880 1712-345678');
  const [isLocating, setIsLocating] = useState(false);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | undefined>({ lat: 23.7508, lng: 90.3751 });
  const [locationSuccess, setLocationSuccess] = useState(false);

  const patientConditionsList = [
    { en: 'Cardiac Chest Pain', bn: 'বুকে তীব্র ব্যথা (হার্ট)' },
    { en: 'Unconscious / Fainted', bn: 'অচেতন / অজ্ঞান' },
    { en: 'Respiratory / Asthma Attack', bn: 'শ্বাসকষ্ট / হাঁপানি' },
    { en: 'Road Accident / Trauma', bn: 'সড়ক দুর্ঘটনা / আঘাত' },
    { en: 'Maternity Emergency', bn: 'প্রসূতি / গর্ভকালীন জরুরি' },
    { en: 'General Patient Transfer', bn: 'সাধারণ রোগী স্থানান্তর' },
  ];

  const currentCategory = AMBULANCE_CATEGORIES.find((c) => c.id === selectedCategory)!;

  const handleDetectLocation = () => {
    setIsLocating(true);
    setLocationSuccess(false);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserCoords({ lat: latitude, lng: longitude });
          setPickupLocation(`Current GPS Location (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`);
          setIsLocating(false);
          setLocationSuccess(true);
        },
        (error) => {
          console.warn('Geolocation error, using default Dhaka coords', error);
          setIsLocating(false);
          setPickupLocation('House 12, Road 27, Dhanmondi, Dhaka');
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    } else {
      setIsLocating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onBook({
      pickupLocation,
      destinationHospital,
      ambulanceType: selectedCategory,
      patientCondition,
      contactNumber,
      userCoords,
    });
  };

  return (
    <div className="bg-slate-50 text-slate-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left / Primary Column: Book Ambulance Form & Quick Actions */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Booking Card */}
            <div className="bg-white rounded-3xl p-6 shadow-xl shadow-slate-200/50 border border-white">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-black text-slate-900">
                  {lang === 'en' ? 'Book an Ambulance' : 'অ্যাম্বুলেন্স বুক করুন'}
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-black px-3 py-1 rounded-full flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  {lang === 'en' ? '18 Nearby Active' : '১৮ টি অ্যাম্বুলেন্স প্রস্তুত'}
                </span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Pickup Location Input with Floating Upper Label */}
                <div className="relative">
                  <label className="text-[10px] font-bold text-slate-400 uppercase absolute left-4 top-2 z-10 flex items-center justify-between right-4">
                    <span>{lang === 'en' ? 'Pickup Location' : 'পিকআপ স্পট'}</span>
                    <button
                      type="button"
                      onClick={handleDetectLocation}
                      disabled={isLocating}
                      className="text-[10px] font-bold text-[#003366] hover:underline cursor-pointer lowercase"
                    >
                      {isLocating ? 'locating...' : 'use my live gps'}
                    </button>
                  </label>
                  <input
                    type="text"
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    required
                    placeholder={lang === 'en' ? 'Enter Current Address' : 'আপনার ঠিকানা লিখুন'}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl pt-7 pb-3 px-4 focus:border-[#003366] focus:bg-white outline-hidden transition-all font-medium text-sm text-slate-900"
                  />
                  <MapPin className="w-4 h-4 text-red-500 absolute right-4 top-8 pointer-events-none" />
                </div>

                {/* Destination Hospital Input */}
                <div className="relative">
                  <label className="text-[10px] font-bold text-slate-400 uppercase absolute left-4 top-2 z-10">
                    {lang === 'en' ? 'Destination Hospital' : 'গন্তব্য হাসপাতাল'}
                  </label>
                  <select
                    value={destinationHospital}
                    onChange={(e) => setDestinationHospital(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl pt-7 pb-3 px-4 focus:border-[#003366] focus:bg-white outline-hidden transition-all font-medium text-sm text-slate-900 cursor-pointer appearance-none"
                  >
                    {HOSPITALS_DATA.map((h) => (
                      <option key={h.id} value={h.name}>
                        {h.name} ({h.icuAvailable} ICU Beds)
                      </option>
                    ))}
                    <option value="Nearest Emergency Hospital">Nearest Emergency Room</option>
                  </select>
                  <Building2 className="w-4 h-4 text-blue-600 absolute right-4 top-8 pointer-events-none" />
                </div>

                {/* Select Ambulance Vehicle Category */}
                <div className="pt-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    {lang === 'en' ? 'Select Vehicle Type' : 'অ্যাম্বুলেন্সের ধরন'}
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {AMBULANCE_CATEGORIES.map((cat) => {
                      const isSelected = selectedCategory === cat.id;
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setSelectedCategory(cat.id)}
                          className={`flex flex-col items-center justify-center p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'border-[#003366] bg-blue-50/50 text-[#003366]'
                              : 'border-slate-100 hover:border-slate-300 text-slate-700 bg-white'
                          }`}
                        >
                          <div className={`w-8 h-8 mb-1 flex items-center justify-center ${isSelected ? 'text-[#003366]' : 'text-slate-400'}`}>
                            <Activity className="w-6 h-6" />
                          </div>
                          <span className="text-xs font-bold text-slate-900">
                            {lang === 'en' ? cat.nameEn : cat.nameBn}
                          </span>
                          <span className="text-[10px] text-slate-500 italic mt-0.5">
                            ৳{cat.baseFare} Est.
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Patient Condition Tags */}
                <div className="space-y-1.5 pt-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    {lang === 'en' ? 'Patient Condition' : 'রোগীর অবস্থা'}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {patientConditionsList.map((cond) => {
                      const label = lang === 'en' ? cond.en : cond.bn;
                      const isSelected = patientCondition === cond.en;
                      return (
                        <button
                          key={cond.en}
                          type="button"
                          onClick={() => setPatientCondition(cond.en)}
                          className={`text-xs px-2.5 py-1 rounded-xl border font-semibold transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-[#003366] text-white border-[#003366]'
                              : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                          }`}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Phone Number Input */}
                <div className="relative">
                  <label className="text-[10px] font-bold text-slate-400 uppercase absolute left-4 top-2 z-10">
                    {lang === 'en' ? 'Emergency Contact Phone' : 'যোগাযোগের মোবাইল নম্বর'}
                  </label>
                  <input
                    type="tel"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    required
                    placeholder="+880 1700-000000"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl pt-7 pb-3 px-4 focus:border-[#003366] focus:bg-white outline-hidden transition-all font-bold text-sm text-slate-900"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute right-4 top-8 pointer-events-none" />
                </div>

                {/* Main Yellow CTA Button */}
                <button
                  type="submit"
                  className="w-full bg-[#FFCC00] hover:bg-amber-400 text-slate-900 font-black py-4 rounded-2xl text-base shadow-lg shadow-amber-100 transition-all active:translate-y-0.5 cursor-pointer uppercase tracking-wider flex items-center justify-center gap-2 mt-2"
                >
                  <Zap className="w-5 h-5 fill-slate-900" />
                  <span>{lang === 'en' ? 'BOOK AMBULANCE NOW' : 'জরুরি অ্যাম্বুলেন্স বুক করুন'}</span>
                </button>
              </form>
            </div>

            {/* Quick Action Navigation Cards */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col gap-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {lang === 'en' ? 'Quick Actions' : 'জরুরি অ্যাকশনসমূহ'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => onNavigateTab('firstaid')}
                  className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 transition-colors text-left cursor-pointer group"
                >
                  <div className="w-10 h-10 bg-emerald-500 text-white rounded-xl flex items-center justify-center shadow-md shadow-emerald-200 shrink-0">
                    <HeartPulse className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">{lang === 'en' ? 'First-Aid Guides' : 'ফার্স্ট-এইড গাইড'}</p>
                    <p className="text-[11px] text-emerald-700">{lang === 'en' ? 'CPR & Choking steps' : 'জরুরি চিকিৎসা পদ্ধতি'}</p>
                  </div>
                </button>

                <button
                  onClick={() => onNavigateTab('hospitals')}
                  className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-indigo-50 hover:bg-indigo-100 transition-colors text-left cursor-pointer group"
                >
                  <div className="w-10 h-10 bg-indigo-500 text-white rounded-xl flex items-center justify-center shadow-md shadow-indigo-200 shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">{lang === 'en' ? 'Hospital Directory' : 'হাসপাতাল তথ্য'}</p>
                    <p className="text-[11px] text-indigo-700">{lang === 'en' ? 'ICU Bed Availability' : 'আইসিইউ বেড স্ট্যাটাস'}</p>
                  </div>
                </button>
              </div>
            </div>

          </div>

          {/* Right / Secondary Column: Feature Display & Assistant Highlights */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Minimalist Hero Feature Banner */}
            <div className="bg-[#003366] text-white rounded-[32px] p-8 shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[360px]">
              {/* Radial backdrop graphic */}
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none"></div>

              <div className="space-y-4 relative z-10 max-w-lg">
                <div className="inline-flex items-center gap-2 bg-white/10 text-amber-400 border border-white/20 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lang === 'en' ? 'Rapid Response Protocol' : 'দ্রুত রেসপন্স প্রোটোকল'}</span>
                </div>

                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
                  {lang === 'en'
                    ? 'Nationwide 24/7 Life Support Ambulance Network'
                    : 'সারাদেশে ২৪/৭ লাইফ সাপোর্ট অ্যাম্বুলেন্স সেবা'}
                </h2>

                <p className="text-slate-200 text-xs sm:text-sm leading-relaxed font-normal">
                  {lang === 'en'
                    ? 'Instant driver dispatch, real-time GPS tracking, and verified paramedics equipped with cardiac defibrillators and oxygen support.'
                    : 'আইসিইউ, সিসিইউ, অক্সিজেন সাপোর্ট এবং অভিজ্ঞ প্যারামেডিক ক্রু সহ তাত্ক্ষণিক অ্যাম্বুলেন্স প্রেরণ।'}
                </p>
              </div>

              {/* Stats Strip */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10 relative z-10">
                <div>
                  <p className="text-2xl font-black text-amber-400">4.8 Min</p>
                  <p className="text-[11px] font-bold text-blue-200 uppercase tracking-wider">{lang === 'en' ? 'Response Time' : 'গড় রেসপন্স'}</p>
                </div>
                <div>
                  <p className="text-2xl font-black text-amber-400">1,200+</p>
                  <p className="text-[11px] font-bold text-blue-200 uppercase tracking-wider">{lang === 'en' ? 'Vehicles' : 'যানবাহন'}</p>
                </div>
                <div>
                  <p className="text-2xl font-black text-amber-400">24/7</p>
                  <p className="text-[11px] font-bold text-blue-200 uppercase tracking-wider">{lang === 'en' ? 'Doctor On-Call' : 'অন-কল ডাক্তার'}</p>
                </div>
              </div>
            </div>

            {/* Assistant Banner Bar */}
            <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#003366] text-amber-400 rounded-2xl flex items-center justify-center shrink-0 font-bold shadow-md">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Emergency Assistant Bot</p>
                  <p className="text-sm font-bold text-slate-900">"Describe your situation or type your location for instant triage"</p>
                </div>
              </div>

              <button
                onClick={() => onNavigateTab('chat')}
                className="px-4 py-2.5 bg-[#003366] hover:bg-blue-900 text-white text-xs font-bold rounded-xl transition-colors shrink-0 cursor-pointer"
              >
                OPEN CHAT
              </button>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
