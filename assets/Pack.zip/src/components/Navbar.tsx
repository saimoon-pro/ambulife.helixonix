import React, { useState } from 'react';
import { 
  Ambulance, 
  PhoneCall, 
  MapPin, 
  Bot, 
  HeartPulse, 
  Building2, 
  Clock, 
  Languages, 
  ShieldAlert, 
  Menu, 
  X,
  Zap
} from 'lucide-react';
import { Language } from '../types';
import { Logo } from './Logo';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  activeBookingId: string | null;
  onOpenSosModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  lang,
  setLang,
  activeBookingId,
  onOpenSosModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'book', labelEn: 'Book Ambulance', labelBn: 'অ্যাম্বুলেন্স বুকিং', icon: Ambulance },
    { id: 'track', labelEn: activeBookingId ? 'Live Tracker 🟢' : 'Live Tracker', labelBn: activeBookingId ? 'লাইভ ট্র্যাক 🟢' : 'লাইভ ট্র্যাক', icon: MapPin },
    { id: 'chat', labelEn: 'AI Assistant', labelBn: 'এআই অ্যাসিস্ট্যান্ট', icon: Bot },
    { id: 'firstaid', labelEn: 'First-Aid Guide', labelBn: 'ফার্স্ট-এইড গাইড', icon: HeartPulse },
    { id: 'hospitals', labelEn: 'Hospitals', labelBn: 'হাসপাতালসমূহ', icon: Building2 },
    { id: 'history', labelEn: 'History & Contacts', labelBn: 'হিস্ট্রি ও কন্টাক্ট', icon: Clock },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Banner & Main Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo & Tagline */}
          <div className="flex items-center cursor-pointer select-none" onClick={() => setCurrentTab('book')}>
            <Logo size="md" variant="light" />
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-full border border-slate-200">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full font-bold text-xs transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#003366] text-white shadow-sm'
                      : 'text-slate-600 hover:text-[#003366] hover:bg-slate-200/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                  <span>{lang === 'en' ? item.labelEn : item.labelBn}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Hotline, Language Switch & SOS Button */}
          <div className="flex items-center gap-4">
            
            {/* Hotline Display */}
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Emergency Hotline</span>
              <a href="tel:10616" className="text-lg font-black text-[#003366] hover:text-blue-700 transition-colors leading-tight">
                10616
              </a>
            </div>

            {/* Language Switch Pill */}
            <button
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              className="px-3 py-1.5 border-2 border-slate-200 rounded-full text-xs font-bold flex items-center gap-1.5 hover:bg-slate-50 text-slate-700 cursor-pointer transition-colors"
            >
              <span className={lang === 'bn' ? 'text-blue-600 font-extrabold' : 'text-slate-500'}>BN</span>
              <span className="text-slate-300">|</span>
              <span className={lang === 'en' ? 'text-blue-600 font-extrabold' : 'text-slate-500'}>EN</span>
            </button>

            {/* Red SOS Button */}
            <button
              onClick={onOpenSosModal}
              className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-full font-black text-xs shadow-md shadow-red-200 flex items-center gap-2 active:scale-95 transition-all cursor-pointer tracking-wider uppercase"
            >
              <ShieldAlert className="w-4 h-4 text-white" />
              <span>SOS BUTTON</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1 shadow-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all text-left ${
                  isActive
                    ? 'bg-[#003366] text-white'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-[#003366]'}`} />
                <span>{lang === 'en' ? item.labelEn : item.labelBn}</span>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
