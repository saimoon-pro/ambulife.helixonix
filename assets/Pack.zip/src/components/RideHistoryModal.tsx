import React, { useState } from 'react';
import { 
  Clock, 
  User, 
  Phone, 
  MapPin, 
  FileText, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Ambulance, 
  Heart,
  Download
} from 'lucide-react';
import { Booking, UserProfile, Language } from '../types';
import { INITIAL_USER_PROFILE } from '../data/mockData';

interface RideHistoryProps {
  pastBookings: Booking[];
  lang: Language;
}

export const RideHistoryModal: React.FC<RideHistoryProps> = ({
  pastBookings,
  lang,
}) => {
  const [profile, setProfile] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [activeTab, setActiveTab] = useState<'history' | 'profile'>('history');
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactRelation, setNewContactRelation] = useState('');

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName || !newContactPhone) return;

    setProfile((prev) => ({
      ...prev,
      emergencyContacts: [
        ...prev.emergencyContacts,
        { name: newContactName, relation: newContactRelation || 'Family', phone: newContactPhone },
      ],
    }));

    setNewContactName('');
    setNewContactPhone('');
    setNewContactRelation('');
  };

  const handleRemoveContact = (idx: number) => {
    setProfile((prev) => ({
      ...prev,
      emergencyContacts: prev.emergencyContacts.filter((_, i) => i !== idx),
    }));
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      
      {/* Tab Switcher Header */}
      <div className="bg-[#003366] text-white rounded-3xl p-6 shadow-xl mb-8 border border-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-white">
            {lang === 'en' ? 'Ride History & Emergency Profile' : 'রাইড হিস্ট্রি ও জরুরি প্রোফাইল'}
          </h1>
          <p className="text-xs text-slate-200 mt-1">
            {lang === 'en'
              ? 'View past ambulance invoices and manage emergency contacts for auto-SOS alerts.'
              : 'অ্যাম্বুলেন্স ব্যবহারের চালান ও জরুরি পরিচিতিদের নম্বর পরিচালনা করুন।'}
          </p>
        </div>

        <div className="flex bg-white/10 p-1.5 rounded-2xl border border-white/20">
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'history' ? 'bg-[#FFCC00] text-slate-950 shadow-md' : 'text-slate-200 hover:text-white'
            }`}
          >
            {lang === 'en' ? 'Dispatch Logs' : 'বুকিং লগ'}
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'profile' ? 'bg-[#FFCC00] text-slate-950 shadow-md' : 'text-slate-200 hover:text-white'
            }`}
          >
            {lang === 'en' ? 'Emergency Profile' : 'মেডিকেল প্রোফাইল'}
          </button>
        </div>
      </div>

      {/* History Log Section */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {pastBookings.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto my-8">
              <Clock className="w-12 h-12 text-slate-400 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-slate-900">
                {lang === 'en' ? 'No Dispatch Records Found' : 'কোনো রাইড হিস্ট্রি নেই'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {lang === 'en' ? 'Your future emergency ambulance receipts will appear here.' : 'আপনার অ্যাম্বুলেন্স ইনভয়েসসমূহ এখানে প্রদর্শিত হবে।'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {pastBookings.map((b) => (
                <div key={b.id} className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="bg-blue-100 text-blue-900 p-2 rounded-xl font-bold">🚑</span>
                      <div>
                        <p className="font-extrabold text-sm text-slate-900">#{b.id}</p>
                        <p className="text-[11px] text-slate-500">{new Date(b.createdAt).toLocaleString()}</p>
                      </div>
                    </div>

                    <span className={`text-xs font-black px-2.5 py-1 rounded-full uppercase ${
                      b.status === 'cancelled' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {b.status}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs font-medium text-slate-700">
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-red-500 shrink-0" />
                      <strong>From:</strong> {b.pickupLocation}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                      <strong>To:</strong> {b.destinationHospital}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <User className="w-4 h-4 text-amber-600 shrink-0" />
                      <strong>Driver:</strong> {b.driver.name} ({b.driver.vehicleNo})
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Paid</span>
                      <span className="text-lg font-black text-slate-900">৳{b.fareEstimate}</span>
                    </div>

                    <button
                      onClick={() => alert(`Invoice #${b.id} downloaded.`)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold px-3 py-2 rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" /> Receipt PDF
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Emergency Profile Section */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* User Details */}
          <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 shadow-md p-6 space-y-4">
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <User className="w-5 h-5 text-blue-900" /> Patient Medical Card
            </h3>

            <div className="space-y-3 text-xs font-semibold text-slate-700">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Full Name</span>
                <span className="text-sm font-black text-slate-900">{profile.name}</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Primary Phone</span>
                <span className="text-sm font-black text-slate-900">{profile.phone}</span>
              </div>

              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-950">
                <span className="text-amber-800 block text-[10px] uppercase font-bold">Blood Group</span>
                <span className="text-base font-black text-amber-900">{profile.bloodGroup}</span>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Known Medical Conditions</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {profile.medicalConditions.map((cond, idx) => (
                    <span key={idx} className="bg-slate-200 text-slate-800 text-[11px] font-bold px-2 py-0.5 rounded">
                      {cond}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Contacts Form & List */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 shadow-md p-6 space-y-6">
            <div>
              <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Phone className="w-5 h-5 text-amber-500" /> Emergency SOS Contacts
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                These numbers will receive instant SMS alerts with your live GPS location when an ambulance is booked.
              </p>
            </div>

            {/* List */}
            <div className="space-y-2">
              {profile.emergencyContacts.map((contact, idx) => (
                <div key={idx} className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <p className="text-sm font-extrabold text-slate-900">{contact.name}</p>
                    <p className="text-xs text-slate-500 font-medium">{contact.relation} • {contact.phone}</p>
                  </div>

                  <button
                    onClick={() => handleRemoveContact(idx)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add New Contact Form */}
            <form onSubmit={handleAddContact} className="pt-4 border-t border-slate-100 space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wide">Add Emergency Contact</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="Contact Name"
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                />
                <input
                  type="text"
                  placeholder="Relation (e.g. Spouse)"
                  value={newContactRelation}
                  onChange={(e) => setNewContactRelation(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                />
                <input
                  type="tel"
                  placeholder="+880 1700-000000"
                  value={newContactPhone}
                  onChange={(e) => setNewContactPhone(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold"
                />
              </div>

              <button
                type="submit"
                className="bg-blue-900 hover:bg-blue-800 text-white text-xs font-extrabold py-2.5 px-4 rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 text-amber-400" /> Save Contact
              </button>
            </form>
          </div>

        </div>
      )}

    </div>
  );
};
