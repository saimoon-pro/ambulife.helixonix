import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  Phone, 
  Ambulance, 
  HeartPulse, 
  CheckCircle2, 
  User, 
  Zap,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { ChatMessage, Language, AmbulanceType } from '../types';

interface AIChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onBookFromChat: (bookingData: {
    pickupLocation: string;
    destinationHospital: string;
    ambulanceType: AmbulanceType;
    patientCondition: string;
  }) => void;
}

export const AIChatbotModal: React.FC<AIChatbotModalProps> = ({
  isOpen,
  onClose,
  lang,
  onBookFromChat,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: lang === 'en'
        ? "Hello! I am Ambulife AI Emergency Assistant. Describe what happened or type your location (e.g. 'I need an ICU ambulance at Dhanmondi'). I can assess symptoms, give instant CPR tips, or book an ambulance for you right now."
        : "হ্যালো! আমি অ্যাম্বুলাইফ এআই জরুরি সহকারী। কী ঘটেছে বলুন অথবা আপনার এলাকা জানান (যেমন: 'ধানমণ্ডিতে আইসিইউ অ্যাম্বুলেন্স লাগবে')। আমি ফার্স্ট-এইড পরামর্শ প্রদান ও অ্যাম্বুলেন্স বুক করতে সক্ষম।",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            content: m.text,
          })),
        }),
      });

      if (!res.ok) throw new Error('API error');
      const data = await res.json();

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.reply || data.text || "I am monitoring your request.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        firstAidSteps: data.firstAidSteps,
        isEmergency: data.isEmergency,
        bookingRecommendation: data.bookingRecommendation,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.warn('Chat failure fallback', err);
      const fallbackMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: lang === 'en'
          ? "For immediate emergency response, please call hotline 10616 or press 'Book Ambulance' below."
          : "জরুরি সাহায্যের জন্য অনুগ্রহ করে ১০৬১৬ নম্বরে কল দিন বা নিচে বুকিং বাটনে চাপুন।",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    { en: '💓 CPR Steps', bn: '💓 সিপিআর নিয়ম' },
    { en: '🫁 Choking Emergency', bn: '🫁 দম বন্ধ হওয়া' },
    { en: '🧠 Stroke Symptoms (FAST)', bn: '🧠 স্ট্রোকের লক্ষণ' },
    { en: '🚑 Book ICU Ambulance Dhanmondi', bn: '🚑 ধানমণ্ডিতে আইসিইউ অ্যাম্বুলেন্স' },
  ];

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full h-[620px] max-h-[92vh] shadow-2xl flex flex-col border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-[#003366] text-white p-4 px-6 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="bg-[#FFCC00] text-slate-950 p-2 rounded-2xl font-bold">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base flex items-center gap-2 text-white">
                Ambulife AI Emergency Bot
                <span className="bg-[#FFCC00] text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full">
                  24/7 Live
                </span>
              </h3>
              <p className="text-xs text-slate-200 font-medium">
                {lang === 'en' ? 'Natural language triage & instant chat booking' : 'জরুরি পরামর্শ ও চ্যাটের মাধ্যমে সরাসরি বুকিং'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-200 hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-50">
          {messages.map((m) => {
            const isUser = m.sender === 'user';
            return (
              <div
                key={m.id}
                className={`flex gap-3 max-w-[85%] ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    isUser ? 'bg-[#FFCC00] text-slate-950' : 'bg-[#003366] text-amber-400'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div className="space-y-2">
                  <div
                    className={`p-4 rounded-3xl text-sm leading-relaxed ${
                      isUser
                        ? 'bg-[#003366] text-white rounded-tr-none shadow-xs'
                        : 'bg-white text-slate-900 border border-slate-200 shadow-xs rounded-tl-none'
                    }`}
                  >
                    <p className="font-medium whitespace-pre-wrap">{m.text}</p>

                    {/* Step-by-Step First Aid Cards if included */}
                    {m.firstAidSteps && m.firstAidSteps.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5">
                        <p className="text-xs font-extrabold uppercase tracking-wide text-amber-600 flex items-center gap-1">
                          <HeartPulse className="w-3.5 h-3.5" /> Emergency First Aid Steps:
                        </p>
                        <ol className="list-decimal list-inside text-xs space-y-1 text-slate-700 font-medium">
                          {m.firstAidSteps.map((step, idx) => (
                            <li key={idx} className="bg-slate-50 p-2 rounded-xl border border-slate-200">
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Direct One-Click Booking Card inside Chat */}
                    {m.bookingRecommendation && (
                      <div className="mt-4 p-3 bg-amber-50 border border-amber-300 rounded-2xl space-y-2">
                        <p className="text-xs font-extrabold text-amber-900 flex items-center gap-1">
                          <Zap className="w-4 h-4 text-amber-600 fill-amber-500" /> Suggested Ambulance Booking:
                        </p>
                        <p className="text-xs text-slate-700">
                          <strong>Type:</strong> {m.bookingRecommendation.recommendedType.toUpperCase()} Ambulance
                          {m.bookingRecommendation.pickup && <> • <strong>Pickup:</strong> {m.bookingRecommendation.pickup}</>}
                        </p>
                        <button
                          onClick={() => {
                            onBookFromChat({
                              pickupLocation: m.bookingRecommendation?.pickup || 'Current Location',
                              destinationHospital: m.bookingRecommendation?.hospital || 'Square Hospital Dhaka',
                              ambulanceType: m.bookingRecommendation?.recommendedType || 'icu',
                              patientCondition: 'Chat Assistant Triage',
                            });
                            onClose();
                          }}
                          className="w-full bg-[#FFCC00] hover:bg-amber-400 text-slate-950 font-black text-xs py-2.5 px-3 rounded-xl shadow-sm flex items-center justify-center gap-1 cursor-pointer uppercase tracking-wider"
                        >
                          <Ambulance className="w-4 h-4" /> Confirm & Book Dispatch Now
                        </button>
                      </div>
                    )}
                  </div>

                  <span className="text-[10px] text-slate-400 block px-1">
                    {m.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex gap-3 max-w-[80%]">
              <div className="w-8 h-8 rounded-full bg-blue-900 text-amber-400 flex items-center justify-center text-xs font-bold">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-white border border-slate-200 p-4 rounded-2xl text-xs font-bold text-slate-500 shadow-xs flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-amber-500 animate-bounce"></span>
                <span>Ambulife AI is processing symptom triage...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Triage Shortcuts */}
        <div className="p-3 bg-white border-t border-slate-200">
          <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(lang === 'en' ? qp.en : qp.bn)}
                className="text-xs font-bold bg-slate-100 hover:bg-amber-100 hover:text-amber-900 text-slate-700 px-3 py-1.5 rounded-full border border-slate-200 whitespace-nowrap transition-colors cursor-pointer"
              >
                {lang === 'en' ? qp.en : qp.bn}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2 mt-1"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={lang === 'en' ? "Type medical situation or 'Book Ambulance at Mirpur'..." : "কী ঘটেছে লিখুন বা বলুন..."}
              className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-4 py-3 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:bg-white outline-hidden"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold p-3 rounded-xl shadow-md cursor-pointer transition-all"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
