import React, { useState, useEffect } from 'react';
import { 
  HeartPulse, 
  Wind, 
  ShieldAlert, 
  Brain, 
  Phone, 
  Search, 
  Play, 
  Square, 
  Volume2, 
  VolumeX, 
  Zap,
  Info,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { Language, FirstAidGuide } from '../types';
import { FIRST_AID_GUIDES } from '../data/mockData';

interface FirstAidSectionProps {
  lang: Language;
  onBookClick: () => void;
}

export const FirstAidSection: React.FC<FirstAidSectionProps> = ({
  lang,
  onBookClick,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeGuide, setActiveGuide] = useState<FirstAidGuide>(FIRST_AID_GUIDES[0]);

  // CPR Metronome State (110 BPM rhythm = ~545ms per compress)
  const [metronomeActive, setMetronomeActive] = useState(false);
  const [pulseTick, setPulseTick] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (metronomeActive) {
      interval = setInterval(() => {
        setPulseTick((prev) => !prev);
      }, 545);
    }
    return () => clearInterval(interval);
  }, [metronomeActive]);

  const categories = [
    { id: 'all', labelEn: 'All Guides', labelBn: 'সকল গাইড' },
    { id: 'cardiac', labelEn: 'CPR & Heart', labelBn: 'সিপিআর ও হার্ট' },
    { id: 'choking', labelEn: 'Choking', labelBn: 'দম বন্ধ হওয়া' },
    { id: 'bleeding', labelEn: 'Severe Bleeding', labelBn: 'রক্তপাত' },
    { id: 'stroke', labelEn: 'Stroke (F.A.S.T)', labelBn: 'স্ট্রোক' },
  ];

  const filteredGuides = FIRST_AID_GUIDES.filter((g) => {
    const matchesCat = selectedCategory === 'all' || g.category === selectedCategory;
    const title = lang === 'en' ? g.titleEn.toLowerCase() : g.titleBn.toLowerCase();
    const query = searchQuery.toLowerCase();
    return matchesCat && (title.includes(query) || g.category.includes(query));
  });

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      
      {/* Title & Banner */}
      <div className="bg-[#003366] text-white rounded-3xl p-6 sm:p-8 shadow-xl mb-8 border border-white flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-white/10 text-amber-400 border border-white/20 px-3 py-1 rounded-full text-xs font-extrabold uppercase">
            <HeartPulse className="w-4 h-4" />
            {lang === 'en' ? 'Lifesaving First-Aid Library' : 'জরুরি ফার্স্ট-এইড গাইডলাইন'}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {lang === 'en' ? 'Instant First-Aid & Emergency Action Guides' : 'জরুরি পরিস্থিতিতে প্রাণরক্ষার ফার্স্ট-এইড নির্দেশিকা'}
          </h1>
          <p className="text-slate-200 text-xs sm:text-sm">
            {lang === 'en'
              ? 'Clear, medical-reviewed step-by-step guides for choking, CPR, stroke, and hemorrhage while waiting for the ambulance.'
              : 'অ্যাম্বুলেন্স আসার আগে আশঙ্কাজনক রোগীর জীবন রক্ষায় আন্তর্জাতিক মানের প্রাথমিক চিকিৎসাসমূহ।'}
          </p>
        </div>

        {/* SOS Hotline Directory Bar */}
        <div className="bg-white/10 border border-white/20 p-4 rounded-2xl w-full md:w-auto text-center shrink-0">
          <p className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
            {lang === 'en' ? 'National Emergency Numbers' : 'জাতীয় জরুরি হেল্পলাইন'}
          </p>
          <div className="flex justify-center gap-3">
            <a href="tel:999" className="bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold px-3 py-2 rounded-xl flex items-center gap-1 shadow-sm">
              <Phone className="w-3.5 h-3.5" /> 999 (National)
            </a>
            <a href="tel:10616" className="bg-[#FFCC00] hover:bg-amber-400 text-slate-950 text-xs font-extrabold px-3 py-2 rounded-xl flex items-center gap-1 shadow-sm">
              <Zap className="w-3.5 h-3.5 fill-slate-950" /> 10616 (Ambulife)
            </a>
          </div>
        </div>
      </div>

      {/* Category Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-8">
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs font-extrabold transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-[#003366] text-white shadow-sm'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {lang === 'en' ? cat.labelEn : cat.labelBn}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'en' ? 'Search guide (e.g. CPR, choking)...' : 'গাইড খুঁজুন...'}
            className="w-full pl-9 pr-4 py-2.5 bg-white border-2 border-slate-100 rounded-2xl text-xs font-semibold text-slate-900 focus:border-[#003366] outline-hidden transition-all"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Guides List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredGuides.map((guide) => {
            const isSelected = activeGuide.id === guide.id;
            return (
              <div
                key={guide.id}
                onClick={() => setActiveGuide(guide)}
                className={`p-5 rounded-3xl border transition-all cursor-pointer shadow-xs ${
                  isSelected
                    ? 'bg-[#003366] text-white border-[#003366] shadow-md'
                    : 'bg-white text-slate-900 border-white hover:border-slate-200 shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-2xl font-bold ${isSelected ? 'bg-[#FFCC00] text-slate-950' : 'bg-blue-50 text-[#003366]'}`}>
                      <HeartPulse className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm sm:text-base">
                        {lang === 'en' ? guide.titleEn : guide.titleBn}
                      </h3>
                      <p className={`text-xs mt-0.5 ${isSelected ? 'text-slate-200' : 'text-slate-500'}`}>
                        {lang === 'en' ? guide.shortSummaryEn : guide.shortSummaryBn}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Active Detailed Guide Card with CPR Rhythm Metronome */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-white shadow-xl shadow-slate-200/50 p-6 sm:p-8 space-y-6">
          
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <span className="bg-amber-100 text-amber-900 text-[11px] font-black uppercase px-2.5 py-1 rounded-full tracking-wider">
                {activeGuide.category.toUpperCase()} EMERGENCY
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                {lang === 'en' ? activeGuide.titleEn : activeGuide.titleBn}
              </h2>
            </div>

            <button
              onClick={onBookClick}
              className="bg-[#FFCC00] hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-2xl text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer uppercase tracking-wider"
            >
              <Zap className="w-4 h-4 fill-slate-950" />
              <span>{lang === 'en' ? 'Book Ambulance' : 'অ্যাম্বুলেন্স ডাকুন'}</span>
            </button>
          </div>

          {/* Urgent Notice Banner */}
          <div className="bg-red-50 border-l-4 border-red-600 p-4 rounded-2xl text-red-900 text-xs font-bold flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <p>{lang === 'en' ? activeGuide.urgentNoticeEn : activeGuide.urgentNoticeBn}</p>
          </div>

          {/* CPR Compression Metronome Tool (If Cardiac / CPR guide is active) */}
          {activeGuide.category === 'cardiac' && (
            <div className="bg-[#003366] text-white rounded-3xl p-5 shadow-lg border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-amber-400 text-sm flex items-center gap-1.5">
                    <HeartPulse className="w-4 h-4 text-amber-400" /> CPR Chest Compression Rhythm Guide (110 BPM)
                  </h4>
                  <p className="text-xs text-slate-200">
                    Push in sync with the visual beat (100-120 compressions per minute).
                  </p>
                </div>

                <button
                  onClick={() => setMetronomeActive(!metronomeActive)}
                  className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
                    metronomeActive
                      ? 'bg-red-600 hover:bg-red-500 text-white'
                      : 'bg-[#FFCC00] hover:bg-amber-400 text-slate-950'
                  }`}
                >
                  {metronomeActive ? <Square className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-slate-950" />}
                  <span>{metronomeActive ? 'STOP METRONOME' : 'START RHYTHM BEAT'}</span>
                </button>
              </div>

              {metronomeActive && (
                <div className="flex items-center justify-center pt-3 pb-1">
                  <div
                    className={`w-20 h-20 rounded-full flex items-center justify-center font-black text-xl transition-all duration-100 ${
                      pulseTick
                        ? 'bg-red-600 text-white scale-110 shadow-lg shadow-red-600/50'
                        : 'bg-white/10 text-slate-300 scale-95'
                    }`}
                  >
                    PUSH!
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step-By-Step List */}
          <div className="space-y-4">
            <h4 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
              {lang === 'en' ? 'Step-by-Step Action Plan' : 'ধাপভিত্তিক করণীয়'}
            </h4>

            <div className="space-y-3">
              {(lang === 'en' ? activeGuide.stepsEn : activeGuide.stepsBn).map((step, idx) => (
                <div key={idx} className="flex items-start gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="bg-[#003366] text-amber-400 font-black w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0">
                    {idx + 1}
                  </div>
                  <p className="text-sm font-semibold text-slate-800 leading-relaxed pt-0.5">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
