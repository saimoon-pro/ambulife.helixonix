/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroBooking } from './components/HeroBooking';
import { LiveTrackerMap } from './components/LiveTrackerMap';
import { AIChatbotModal } from './components/AIChatbotModal';
import { FirstAidSection } from './components/FirstAidSection';
import { HospitalDirectory } from './components/HospitalDirectory';
import { RideHistoryModal } from './components/RideHistoryModal';
import { Footer } from './components/Footer';
import { SosModal } from './components/SosModal';
import { AmbulanceType, Booking, Language } from './types';
import { Bot, Sparkles, MessageCircle, Zap } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('book');
  const [lang, setLang] = useState<Language>('en');

  const [activeBooking, setActiveBooking] = useState<Booking | null>(null);
  const [pastBookings, setPastBookings] = useState<Booking[]>([]);

  const [chatModalOpen, setChatModalOpen] = useState(false);
  const [sosModalOpen, setSosModalOpen] = useState(false);

  // Handle Instant Booking Submission
  const handleCreateBooking = async (bookingData: {
    pickupLocation: string;
    destinationHospital: string;
    ambulanceType: AmbulanceType;
    patientCondition: string;
    contactNumber?: string;
    userCoords?: { lat: number; lng: number };
  }) => {
    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData),
      });

      if (!response.ok) throw new Error('Booking failed');

      const newBooking: Booking = await response.json();
      setActiveBooking(newBooking);
      setPastBookings((prev) => [newBooking, ...prev]);

      // Switch to Live GPS Tracker view
      setCurrentTab('track');
    } catch (err) {
      console.error('Failed to create booking', err);
      // Fallback local booking object
      const fallbackBooking: Booking = {
        id: 'AMB-' + Math.floor(100000 + Math.random() * 900000),
        pickupLocation: bookingData.pickupLocation,
        destinationHospital: bookingData.destinationHospital,
        ambulanceType: bookingData.ambulanceType,
        patientCondition: bookingData.patientCondition,
        contactNumber: bookingData.contactNumber || '+880 1700-000000',
        status: 'dispatched',
        driver: {
          name: 'Rafiqul Islam',
          phone: '+880 1711-890234',
          vehicleNo: 'Dhaka Metro-HA 12-4091',
          rating: 4.9,
          avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=150&q=80',
          latitude: 23.7531,
          longitude: 90.3807,
        },
        pickupCoords: bookingData.userCoords || { lat: 23.7508, lng: 90.3751 },
        hospitalCoords: { lat: 23.7531, lng: 90.3807 },
        etaMinutes: 5,
        fareEstimate: 2000,
        createdAt: new Date().toISOString(),
      };

      setActiveBooking(fallbackBooking);
      setPastBookings((prev) => [fallbackBooking, ...prev]);
      setCurrentTab('track');
    }
  };

  const handleCancelBooking = async (bookingId: string) => {
    try {
      await fetch(`/api/bookings/${bookingId}/cancel`, { method: 'POST' });
    } catch (e) {
      console.warn('Cancel request error', e);
    }

    if (activeBooking && activeBooking.id === bookingId) {
      const updated = { ...activeBooking, status: 'cancelled' as const };
      setActiveBooking(updated);
      setPastBookings((prev) =>
        prev.map((b) => (b.id === bookingId ? updated : b))
      );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-amber-400 selection:text-slate-950">
      
      {/* Top Header */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'chat') {
            setChatModalOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        lang={lang}
        setLang={setLang}
        activeBookingId={activeBooking && activeBooking.status !== 'cancelled' ? activeBooking.id : null}
        onOpenSosModal={() => setSosModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'book' && (
          <HeroBooking
            lang={lang}
            onBook={handleCreateBooking}
            onNavigateTab={(tab) => {
              if (tab === 'chat') setChatModalOpen(true);
              else setCurrentTab(tab);
            }}
          />
        )}

        {currentTab === 'track' && (
          <LiveTrackerMap
            booking={activeBooking}
            lang={lang}
            onCancelBooking={handleCancelBooking}
            onNewBooking={() => setCurrentTab('book')}
          />
        )}

        {currentTab === 'firstaid' && (
          <FirstAidSection
            lang={lang}
            onBookClick={() => setCurrentTab('book')}
          />
        )}

        {currentTab === 'hospitals' && (
          <HospitalDirectory
            lang={lang}
            onSelectHospitalForBooking={(hospitalName) => {
              setCurrentTab('book');
            }}
          />
        )}

        {currentTab === 'history' && (
          <RideHistoryModal
            pastBookings={pastBookings}
            lang={lang}
          />
        )}
      </main>

      {/* Floating AI Chatbot Action Launcher Button */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
        <button
          onClick={() => setChatModalOpen(true)}
          className="animate-bounce bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 text-amber-400 p-4 rounded-full shadow-2xl hover:shadow-amber-500/30 border-2 border-amber-400 flex items-center justify-center transition-all transform active:scale-95 cursor-pointer group"
          title="Open AI Emergency Assistant"
        >
          <Bot className="w-7 h-7 text-amber-400 group-hover:rotate-12 transition-transform" />
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500"></span>
          </span>
        </button>
      </div>

      {/* AI Assistant Chat Modal */}
      <AIChatbotModal
        isOpen={chatModalOpen}
        onClose={() => setChatModalOpen(false)}
        lang={lang}
        onBookFromChat={(bookingData) => {
          handleCreateBooking({
            pickupLocation: bookingData.pickupLocation,
            destinationHospital: bookingData.destinationHospital,
            ambulanceType: bookingData.ambulanceType,
            patientCondition: bookingData.patientCondition,
          });
        }}
      />

      {/* SOS Helpline Modal */}
      <SosModal
        isOpen={sosModalOpen}
        onClose={() => setSosModalOpen(false)}
        lang={lang}
      />

      {/* Footer */}
      <Footer
        lang={lang}
        onNavigateTab={(tab) => {
          if (tab === 'chat') setChatModalOpen(true);
          else setCurrentTab(tab);
        }}
        onOpenSosModal={() => setSosModalOpen(true)}
      />

    </div>
  );
}
