export type Language = 'en' | 'bn';

export type AmbulanceType = 'basic' | 'icu' | 'ac' | 'freezer' | 'air';

export interface AmbulanceCategory {
  id: AmbulanceType;
  nameEn: string;
  nameBn: string;
  descriptionEn: string;
  descriptionBn: string;
  iconName: string;
  baseFare: number;
  perKm: number;
  estTimeMin: number;
  badgeEn: string;
  badgeBn: string;
  features: string[];
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  phone: string;
  emergencyPhone: string;
  specialties: string[];
  rating: number;
  lat: number;
  lng: number;
  icuAvailable: number;
  generalBeds: number;
  distanceKm?: number;
}

export interface DriverInfo {
  name: string;
  phone: string;
  vehicleNo: string;
  rating: number;
  avatar: string;
  latitude: number;
  longitude: number;
}

export interface Booking {
  id: string;
  pickupLocation: string;
  destinationHospital: string;
  ambulanceType: AmbulanceType;
  patientCondition: string;
  contactNumber: string;
  status: 'searching' | 'dispatched' | 'en_route' | 'arrived' | 'completed' | 'cancelled';
  driver: DriverInfo;
  pickupCoords: { lat: number; lng: number };
  hospitalCoords: { lat: number; lng: number };
  etaMinutes: number;
  fareEstimate: number;
  createdAt: string;
}

export interface FirstAidGuide {
  id: string;
  category: 'cardiac' | 'choking' | 'bleeding' | 'burns' | 'stroke' | 'fracture';
  titleEn: string;
  titleBn: string;
  shortSummaryEn: string;
  shortSummaryBn: string;
  urgentNoticeEn: string;
  urgentNoticeBn: string;
  stepsEn: string[];
  stepsBn: string[];
  icon: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  firstAidSteps?: string[];
  isEmergency?: boolean;
  bookingRecommendation?: {
    recommendedType: AmbulanceType;
    pickup?: string;
    hospital?: string;
  };
}

export interface UserProfile {
  name: string;
  phone: string;
  bloodGroup: string;
  medicalConditions: string[];
  savedAddresses: { label: string; address: string; lat: number; lng: number }[];
  emergencyContacts: { name: string; relation: string; phone: string }[];
}
